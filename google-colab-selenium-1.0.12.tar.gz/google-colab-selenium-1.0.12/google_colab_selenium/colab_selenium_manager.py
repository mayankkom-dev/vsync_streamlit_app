import subprocess

from google_colab_selenium.spinner import Spinner
from google_colab_selenium.exceptions import (
    ChromeDriverPathError, InstallChromeError, GoogleColabSeleniumError
)

from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.selenium_manager import SeleniumManager


class ColabSeleniumManager:
    default_colab_options = [
        '--headless',
        '--no-sandbox',
        '--disable-dev-shm-usage',
        '--lang=en'
    ]
    # both true freeze and no response
    _downloaded_chrome = False
    _updated_apt = True

    update_apt = ['apt', 'update', '-y']
    upgrade_apt = ['apt', 'upgrade', '-y']

    download_command = ['curl', '-o', 'google-chrome-stable_current_amd64.deb', 'https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb']
    # install_command = ['apt', 'install', './google-chrome-stable_current_amd64.deb', '-y']
    install_command = ['dpkg', '-i', './google-chrome-stable_current_amd64.deb']
    
    clean_up_command = ['rm', 'google-chrome-stable_current_amd64.deb']

    chromedriver_path: str = None

    def __init__(self, base_options: Options, log_output=None):
        if not self._updated_apt:
            self.update_upgrade_apt()

        if not self._downloaded_chrome:
            self.install_chrome()

        self.options = self.default_options(base_options or Options())
        self.service = self.get_service(log_output)
        

    @classmethod
    def update_upgrade_apt(cls) -> None:
        try:
            with Spinner('Updating and upgrading APT', done='Updated and upgraded APT'):
                subprocess.run(cls.update_apt, check=True)
                subprocess.run(cls.upgrade_apt, check=True)
        
        except Exception as e:
            raise GoogleColabSeleniumError('Failed to update and upgrade APT') from e

        else:
            cls._updated_apt = True

    @classmethod
    def install_chrome(cls) -> None:
        """
        To Install Google-Chrome-Stable, the first command uses CURL to download
        the debian file. Next Advanced Package Tool installs the file and once
        it's installed, the .deb file, which is no longer needed, is deleted.
        """
        try:
            with Spinner('Downloading Google Chrome', done='Downloaded Google Chrome'):
                subprocess.run(cls.download_command, check=True)
                subprocess.run(cls.install_command, check=True)
                # subprocess.run(cls.clean_up_command, check=True)

        except Exception as e:
            raise InstallChromeError("Failed to install Google Chrome.") from e

        else:
            cls._downloaded_chrome = True

    @classmethod
    def default_options(cls, options: Options) -> Options:
        for default in cls.default_colab_options:
            options.add_argument(default)

        return options

    @classmethod
    def get_service(cls, log_output: str) -> Service:
        path = cls.chromedriver_path or cls.prepare_driver()
        if log_output is not None:
            return Service(path, log_output=log_output)
        else:
            return Service(path)
                           
    @classmethod
    def prepare_driver(cls) -> str:
        try:
            path = SeleniumManager().driver_location(Options())
            cls.chromedriver_path = path
            return path

        except Exception as e:
            raise ChromeDriverPathError("Failed to find ChromeDriver.") from e





